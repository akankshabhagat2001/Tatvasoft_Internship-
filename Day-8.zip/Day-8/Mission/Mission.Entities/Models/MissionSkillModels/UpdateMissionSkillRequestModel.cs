﻿
namespace Mission.Entities.Models.MissionSkillModels
{
    public class UpdateMissionSkillRequestModel : AddMissionSkillRequestModel
    {
        public int Id { get; set; }
    }
}
