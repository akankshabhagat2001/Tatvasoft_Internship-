﻿namespace Mission.Entity.Models.MissionSkillModels
{
    public class UpdateMissionSkillRequestModel : AddMissionSkillRequestModel
    {
        public int Id { get; set; }
    }
}
