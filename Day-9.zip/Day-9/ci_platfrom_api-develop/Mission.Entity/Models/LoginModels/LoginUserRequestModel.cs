﻿namespace Mission.Entity.Models.LoginModels
{
    public class LoginUserRequestModel
    {
        public string EmailAddress { get; set; }

        public string Password { get; set; }
    }
}
