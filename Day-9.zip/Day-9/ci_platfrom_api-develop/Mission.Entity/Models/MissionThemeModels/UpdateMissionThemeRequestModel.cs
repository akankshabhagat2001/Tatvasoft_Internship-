﻿namespace Mission.Entity.Models.MissionThemeModels
{
    public class UpdateMissionThemeRequestModel : AddMissionThemeRequestModel
    {
        public int Id { get; set; }
    }
}
