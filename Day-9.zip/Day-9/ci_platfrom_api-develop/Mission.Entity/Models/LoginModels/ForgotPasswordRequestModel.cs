﻿namespace Mission.Entity.Models.LoginModels
{
    public class ForgotPasswordRequestModel
    {
        public string EmailAddress { get; set; }

        public string BaseUrl { get; set; }
    }
}
