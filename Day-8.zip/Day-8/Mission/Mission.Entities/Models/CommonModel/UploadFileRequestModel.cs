﻿namespace Mission.Entities.Models.CommonModel
{
    public class UploadFileRequestModel
    {
        public string ModuleName { get; set; }
    }
}
