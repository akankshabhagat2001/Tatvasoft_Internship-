﻿namespace Mission.Entity.Models.VolunteeringTimesheetModels
{
    public class UpdateVolunteeringHoursRequestModel : AddVolunteeringHoursRequestModel
    {
        public int Id { get; set; }
    }
}
